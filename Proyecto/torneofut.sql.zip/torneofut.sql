-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-10-2013 a las 23:26:53
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `torneofut`
--
CREATE DATABASE IF NOT EXISTS `torneofut` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `torneofut`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `Id_Categoria` int(11) NOT NULL,
  `Tipo` varchar(15) NOT NULL,
  PRIMARY KEY (`Id_Categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`Id_Categoria`, `Tipo`) VALUES
(1, 'Master'),
(2, 'Especial'),
(3, '1ra. Especial'),
(4, '2da. Fuerza');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `delegado`
--

CREATE TABLE IF NOT EXISTS `delegado` (
  `Id_Delegado` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Telefono` int(20) NOT NULL,
  PRIMARY KEY (`Id_Delegado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `delegado`
--

INSERT INTO `delegado` (`Id_Delegado`, `Nombre`, `Direccion`, `Telefono`) VALUES
(1, 'Juan Gutierrez', 'Francisco I. Madero  #101 Zona Centro\r\n', 6151270),
(2, 'Luis Aguilar', 'Alvaro Obregon # 206 Zona Centro\r\n', 2147483647),
(3, 'Antonio Muñoz', 'Villa de los Reyes # 502 Col. Villas del Romeral\r\n', 2147483647);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dueño`
--

CREATE TABLE IF NOT EXISTS `dueño` (
  `Id_Dueño` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Telefono` int(20) NOT NULL,
  `Id_Delegado` int(11) NOT NULL,
  PRIMARY KEY (`Id_Dueño`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `dueño`
--

INSERT INTO `dueño` (`Id_Dueño`, `Nombre`, `Direccion`, `Telefono`, `Id_Delegado`) VALUES
(1, 'Luis Rangel', 'Cerro del cubilete # 116 Col. Jacarandas\r\n', 2147483647, 8),
(2, 'Jose Ramírez', '5 Mayo #103 Zona Centro\r\n', 6138975, 6),
(3, 'Gabriel Rodriguez', 'Azucena # 1203 Col. Las Flores\r\n', 2147483647, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo`
--

CREATE TABLE IF NOT EXISTS `equipo` (
  `Id_Equipo` int(11) NOT NULL,
  `Nom_Equipo` varchar(25) NOT NULL,
  `Playera` varchar(10) NOT NULL,
  `Short` varchar(10) NOT NULL,
  `Medias` varchar(10) NOT NULL,
  `Id_Categorias` int(11) NOT NULL,
  `Id_Dueño` int(11) NOT NULL,
  `Id_Tabla''` int(11) NOT NULL,
  PRIMARY KEY (`Id_Equipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `equipo`
--

INSERT INTO `equipo` (`Id_Equipo`, `Nom_Equipo`, `Playera`, `Short`, `Medias`, `Id_Categorias`, `Id_Dueño`, `Id_Tabla''`) VALUES
(1, 'Dep.CHAYS', 'azul', 'blanco', 'azules', 1, 3, 0),
(2, 'San Francisco', 'Rojo', 'Blanco', 'Blancas', 1, 1, 0),
(3, 'Porto FC', 'Amarillo', 'Negro', 'Amarillas', 2, 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jornada`
--

CREATE TABLE IF NOT EXISTS `jornada` (
  `Id_Jornada` int(11) NOT NULL,
  `Hora` time NOT NULL,
  `Fecha` date NOT NULL,
  PRIMARY KEY (`Id_Jornada`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `jornada`
--

INSERT INTO `jornada` (`Id_Jornada`, `Hora`, `Fecha`) VALUES
(1, '10:00:00', '2013-10-06'),
(2, '10:00:00', '2013-10-16'),
(3, '10:00:00', '2013-10-20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juega`
--

CREATE TABLE IF NOT EXISTS `juega` (
  `Id_Equipo` int(11) NOT NULL,
  `Id_Torneo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `juega`
--

INSERT INTO `juega` (`Id_Equipo`, `Id_Torneo`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugador`
--

CREATE TABLE IF NOT EXISTS `jugador` (
  `Id_Jugador` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Telefono` int(20) NOT NULL,
  `Id_Equipo` int(11) NOT NULL,
  PRIMARY KEY (`Id_Jugador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `jugador`
--

INSERT INTO `jugador` (`Id_Jugador`, `Nombre`, `Direccion`, `Telefono`, `Id_Equipo`) VALUES
(1, 'Luis Alberto Gonzales', 'Zaragoza #128 zona centro\r\n', 6198789, 1),
(2, 'Antonio Luna Ramos', 'Francisco I. Madero #737 zona centro\r\n', 6102938, 2),
(3, 'Rodolfo Zarate Nieves', '5 de Mayo #998 zona centro \r\n', 6126354, 3),
(4, 'Andres Morales Salinas', '16 de Septiembre #282 zona centro\r\n', 6192837, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pertenece`
--

CREATE TABLE IF NOT EXISTS `pertenece` (
  `Id_Jornada` int(11) NOT NULL,
  `Id_Torneo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `pertenece`
--

INSERT INTO `pertenece` (`Id_Jornada`, `Id_Torneo`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posiciones`
--

CREATE TABLE IF NOT EXISTS `posiciones` (
  `Id_Tabla` int(11) NOT NULL,
  `Equipo` varchar(25) NOT NULL,
  `Juegos_Jugados` int(11) NOT NULL DEFAULT '0',
  `Juegos_Ganados` int(11) NOT NULL DEFAULT '0',
  `Juegos_Empatados` int(11) NOT NULL DEFAULT '0',
  `Juegos_Perdidos` int(11) NOT NULL DEFAULT '0',
  `Goles_Favor` int(11) NOT NULL DEFAULT '0',
  `Goles_Contra` int(11) NOT NULL DEFAULT '0',
  `Diferencia_Goles` int(11) NOT NULL DEFAULT '0',
  `Juegos_Perdidos_Default` int(11) NOT NULL DEFAULT '0',
  `Puntos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id_Tabla`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `posiciones`
--

INSERT INTO `posiciones` (`Id_Tabla`, `Equipo`, `Juegos_Jugados`, `Juegos_Ganados`, `Juegos_Empatados`, `Juegos_Perdidos`, `Goles_Favor`, `Goles_Contra`, `Diferencia_Goles`, `Juegos_Perdidos_Default`, `Puntos`) VALUES
(1, 'Dep.CHAYS', 0, 0, 0, 0, 0, 0, 0, 2, 0),
(2, 'San Francisco', 1, 1, 0, 0, 10, 1, 9, 0, 6),
(3, 'Porto FC', 1, 1, 0, 0, 6, 0, 6, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `torneo`
--

CREATE TABLE IF NOT EXISTS `torneo` (
  `Id_Torneo` int(11) NOT NULL,
  `Horario` time NOT NULL,
  `Fecha` date NOT NULL,
  `Equipo_1` varchar(25) NOT NULL,
  `Equipo_2` varchar(25) NOT NULL,
  `Id_Categoria` int(11) NOT NULL,
  PRIMARY KEY (`Id_Torneo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `torneo`
--

INSERT INTO `torneo` (`Id_Torneo`, `Horario`, `Fecha`, `Equipo_1`, `Equipo_2`, `Id_Categoria`) VALUES
(1, '10:00:00', '2013-11-02', '1', '2', 1),
(2, '12:00:00', '2013-11-16', '3', '2', 3),
(3, '15:00:00', '2013-11-23', '1', '3', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
